ZI Editor - Pre Release Version -0.10

Author: Patrick Martin
 eMail: zieditor@homehub.info

INSTALLATION

  Create a folder with read/write rights (ex: Documents\zi)
  Copy the ziedit.exe to that folder.  
  Run and enjoy.

UNINSTALLATION

  Delete ziedit.exe and *.chr files that were created.  
  No registry values are used.


LICENSE

  This software is not public domain.  To measure the software 
  usefulness, I require you send an email to the above address.
  In doing so, I will grant use of the software without charge.
  No other method provide you with a license to use the software.
  I will keep you updated when a new version becomes available,
  and will make the latest Manual available via PDF sent to the
  email address when you sent me your email.  Pretty simple.

