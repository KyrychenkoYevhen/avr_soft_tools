# Example Fonts

This is a test of the ZI v5 font specification for TJC/Nextion HMI displays. Use these files at your own risk!
The characterset starts with a space (`0x20`) as the first character and ends with character `0x02D7` using the GB2312 encoding.

The files contain the [ionicons-designerpack](https://github.com/ionic-team/ionicons) in a ZI v5 format.
The original icon files are created by [iconic-team](https://github.com/ionic-team) and licensed under the MIT license.
